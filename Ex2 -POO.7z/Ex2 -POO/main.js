const readline = require('readline');
// Configuração do readline para entrada e saída padrão
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});
// Cria a classe mestre para definição do corpo do programa
class Veiculos {
    _marca
    _nome
    _cilindrada
    _cor
    _cilindrada


    constructor(pMarca, pNome, pCilindrada, pCor, pAceleracao) {
        this._marca = pMarca;
        this._nome = pNome;
        this._cilindrada = pCilindrada;
        this._cor = pCor;
        this._aceleracao = this.nivelAceleracao(pAceleracao);
    }
// Comparação dos parametros introduzidos pelo operador
    nivelAceleracao(nivel) {
        const aceleracaoMinima = 10; 
        
        const aceleracaoMaxima = 200; 
        
        return aceleracaoMinima + (nivel - 1) * ((aceleracaoMaxima - aceleracaoMinima) / 9);
    }

    acelerar() {
        console.log(`${this._nome} está acelerando a ${this._aceleracao.toFixed(2)} km/h!`);
    }

    alterarAceleracao(nivel) {
        if (nivel < 1 || nivel > 10) {
            console.log("Por favor, insira um nível de aceleração entre 1 e 10.");
        } else {
            this._aceleracao = this.nivelAceleracao(nivel);
            console.log(`A aceleração de ${this._nome} foi alterada para ${this._aceleracao.toFixed(2)} km/h (nível ${nivel}).`);
        }
    }
}


// Cria a subclasse Carro vinculada a classe mestre
class Carro extends Veiculos {
    constructor(pMarca, pNome, pCilindrada, pCor, pAceleracao, pPortas) {
        super(pMarca, pNome, pCilindrada, pCor, pAceleracao);
        this._portas = pPortas;
    }

   
}
// Cria a subclasse Moto vinculada a classe mestre
class Moto extends Veiculos {
    constructor(pMarca, pNome, pCilindrada, pCor, pAceleracao, pRodas) {
        super(pMarca, pNome, pCilindrada, pCor, pAceleracao);
        this._rodas = pRodas;
    }
}


// Inicia a introdução do operador ao programa
function iniciarMain() {
    rl.question('Você vai dirigir um Carro ou uma Moto? ', (tipoVeiculo) => {
        if (tipoVeiculo.toLowerCase() === 'carro') {
            criarCarro();
        } else if (tipoVeiculo.toLowerCase() === 'moto') {
            criarMoto();
        } else {
            console.log('Opção inválida! Tente novamente.');
            iniciarMain();  
            
        }
    });
}


// Introduz as perguntas das caracteristicas do parametro Carro
function criarCarro() {
    rl.question('Qual a marca do carro? ', (marca) => {
        rl.question('Qual o nome do carro? ', (nome) => {
            rl.question('Qual a cilindrada do carro? ', (cilindrada) => {
                rl.question('Qual a cor do carro? ', (cor) => {
                    rl.question('Qual o nível de aceleração inicial (1-10)? ', (aceleracao) => {
                        rl.question('Quantas portas o carro tem? ', (portas) => {
                            const meuCarro = new Carro(marca, nome, cilindrada, cor, Number(aceleracao), Number(portas));
                            console.log(`Carro ${meuCarro._nome} criado!`);
                            controlarVeiculo(meuCarro);
                        });
                    });
                });
            });
        });
    });
}


// Introduz as perguntas das carcteristicas do parametro Moto
function criarMoto() {
    rl.question('Qual a marca da moto? ', (marca) => {
        rl.question('Qual o nome da moto? ', (nome) => {
            rl.question('Qual a cilindrada da moto? ', (cilindrada) => {
                rl.question('Qual a cor da moto? ', (cor) => {
                    rl.question('Qual o nível de aceleração inicial (1-10)? ', (aceleracao) => {
                        rl.question('Quantas rodas a moto tem? ', (rodas) => {
                            const minhaMoto = new Moto(marca, nome, cilindrada, cor, Number(aceleracao), Number(rodas));
                            console.log(`Moto ${minhaMoto._nome} criada!`);
                            controlarVeiculo(minhaMoto);
                        });
                    });
                });
            });
        });
    });
}


// Introduz a ação para realizar as alterações na velocidade
function controlarVeiculo(veiculo) {
    rl.question('Você quer acelerar ou alterar a aceleração? (acelerar/alterar) ', (acao) => {
        if (acao.toLowerCase() === 'acelerar') {
            veiculo.acelerar();
            rl.close();
        } else if (acao.toLowerCase() === 'alterar') {
            rl.question('Insira o novo nível de aceleração (1-10): ', (novoNivel) => {
                veiculo.alterarAceleracao(Number(novoNivel));
                rl.close();
            });
        } else {
            console.log('Ação inválida! Tente novamente.');
            controlarVeiculo(veiculo);
        }
    });
}


// Inicia o Programa
iniciarMain();

